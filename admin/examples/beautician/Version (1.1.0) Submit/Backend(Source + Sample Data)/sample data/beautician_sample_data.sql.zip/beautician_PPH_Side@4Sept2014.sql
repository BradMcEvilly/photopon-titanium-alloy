-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 11, 2014 at 02:03 AM
-- Server version: 5.5.9
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `beautician`
--

-- --------------------------------------------------------

--
-- Table structure for table `bc_appusers`
--

CREATE TABLE `bc_appusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `password` text CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `about_me` text CHARACTER SET utf8 NOT NULL,
  `profile_photo` text CHARACTER SET utf8 NOT NULL,
  `background_photo` text CHARACTER SET utf8 NOT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `bc_appusers`
--

INSERT INTO `bc_appusers` VALUES(1, 'Panacea-Soft', '827ccb0eea8a706c4c34a16891f84e7b', 'Teamps.is.cool@gmail.com', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus. Update about me for testing.', '1-profile.jpg', '1-background.jpg', 0, 1, '2014-08-09 18:27:08', NULL);
INSERT INTO `bc_appusers` VALUES(2, 'App User One', '827ccb0eea8a706c4c34a16891f84e7b', 'Pphmit@gmail.com', 'I am app user one. I am fine with it.', '', '<', 0, 1, '2014-08-21 17:03:50', NULL);
INSERT INTO `bc_appusers` VALUES(3, 'App User Two', '827ccb0eea8a706c4c34a16891f84e7b', 'Appuser2@gmail.com', '', '', '', 0, 1, '2014-08-21 17:12:44', NULL);
INSERT INTO `bc_appusers` VALUES(4, 'Jack', '827ccb0eea8a706c4c34a16891f84e7b', 'Jack@gmail.com', '', '', '', 0, 1, '2014-08-21 17:14:28', NULL);
INSERT INTO `bc_appusers` VALUES(5, 'App user Ten', '827ccb0eea8a706c4c34a16891f84e7b', 'User10@gmail.com', 'I am good.', '', '<', 0, 1, '2014-08-21 19:40:36', NULL);
INSERT INTO `bc_appusers` VALUES(6, 'App User 11', '827ccb0eea8a706c4c34a16891f84e7b', 'user11@gmail.com', '', '', '', 0, 1, '2014-08-21 19:57:06', NULL);
INSERT INTO `bc_appusers` VALUES(7, 'app user 12', '827ccb0eea8a706c4c34a16891f84e7b', 'user12@gmail.com', 'I am registered from android. ', '7-profile.jpg', '<', 0, 1, '2014-08-21 21:12:35', NULL);
INSERT INTO `bc_appusers` VALUES(8, 'app user 13', '827ccb0eea8a706c4c34a16891f84e7b', 'user13@gmail.com', 'I am user 13', '', '', 0, 1, '2014-08-21 21:34:03', NULL);
INSERT INTO `bc_appusers` VALUES(9, 'Appuser25', '827ccb0eea8a706c4c34a16891f84e7b', 'Appuser25@gmail.com', 'I am developer for web and Mobile.', '9-profile.jpg', '9-background.jpg', 0, 1, '2014-09-11 00:21:25', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bc_categories`
--

CREATE TABLE `bc_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `is_publish` int(11) NOT NULL DEFAULT '0',
  `ordering` int(5) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `bc_categories`
--

INSERT INTO `bc_categories` VALUES(1, 'For Men', 1, 1, '2014-07-28 17:56:19', NULL);
INSERT INTO `bc_categories` VALUES(2, 'For Women', 1, 2, '2014-07-28 17:56:24', NULL);
INSERT INTO `bc_categories` VALUES(3, 'For Kids', 0, 3, '2014-08-15 00:15:30', NULL);
INSERT INTO `bc_categories` VALUES(4, 'For Soccer Stars', 0, 4, '2014-08-15 00:15:50', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bc_codes`
--

CREATE TABLE `bc_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code` text NOT NULL,
  `is_systemuser` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bc_codes`
--


-- --------------------------------------------------------

--
-- Table structure for table `bc_contactus`
--

CREATE TABLE `bc_contactus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `message` text CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `bc_contactus`
--

INSERT INTO `bc_contactus` VALUES(1, 'Pphan', 'Han@gmail.com', 'Contact us test', 1, '2014-08-12 00:30:18', NULL);
INSERT INTO `bc_contactus` VALUES(2, 'Han', 'Han@gmail.com', 'Contact us message sent from iPod', 1, '2014-08-21 16:46:07', NULL);
INSERT INTO `bc_contactus` VALUES(3, 'Han', 'Han@gmail.com', 'Contact message from iPad ', 1, '2014-08-21 19:37:02', NULL);
INSERT INTO `bc_contactus` VALUES(4, 'hsn', 'han@gmail.com', 'contact message from android', 1, '2014-08-21 21:10:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bc_favourites`
--

CREATE TABLE `bc_favourites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `appuser_id` int(11) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `bc_favourites`
--

INSERT INTO `bc_favourites` VALUES(5, 3, 1, '2014-08-10 16:38:35');
INSERT INTO `bc_favourites` VALUES(6, 4, 1, '2014-08-10 19:42:28');
INSERT INTO `bc_favourites` VALUES(7, 13, 1, '2014-08-10 21:09:17');
INSERT INTO `bc_favourites` VALUES(8, 5, 1, '2014-08-21 15:31:08');
INSERT INTO `bc_favourites` VALUES(9, 17, 1, '2014-08-21 15:47:48');
INSERT INTO `bc_favourites` VALUES(10, 16, 1, '2014-08-21 15:49:43');
INSERT INTO `bc_favourites` VALUES(11, 18, 2, '2014-08-21 19:20:06');
INSERT INTO `bc_favourites` VALUES(12, 14, 6, '2014-08-21 20:15:53');

-- --------------------------------------------------------

--
-- Table structure for table `bc_feeds`
--

CREATE TABLE `bc_feeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `bc_feeds`
--

INSERT INTO `bc_feeds` VALUES(1, 'Package Promotion', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. ', 1, '2014-07-29 22:49:20');
INSERT INTO `bc_feeds` VALUES(2, 'Holiday Promotions 20%', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn''t anything embarrassing hidden in the middle of text.', 1, '2014-07-30 22:19:30');
INSERT INTO `bc_feeds` VALUES(3, 'For Men Only Promotion', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.', 1, '2014-08-09 22:10:34');
INSERT INTO `bc_feeds` VALUES(4, 'For Women Only Promotion', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.', 1, '2014-08-09 22:12:19');
INSERT INTO `bc_feeds` VALUES(5, 'For Kid Promotion', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.', 1, '2014-08-09 22:13:53');

-- --------------------------------------------------------

--
-- Table structure for table `bc_images`
--

CREATE TABLE `bc_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `type` text NOT NULL,
  `description` text NOT NULL,
  `path` text NOT NULL,
  `width` text NOT NULL,
  `height` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=166 ;

--
-- Dumping data for table `bc_images`
--

INSERT INTO `bc_images` VALUES(2, 3, 'item', '1. Aenean commodo ligula eget dolor.', '14074041679.jpg', '194', '260');
INSERT INTO `bc_images` VALUES(3, 3, 'item', '2. Aenean commodo ligula eget dolor.', '140740424018.jpg', '225', '225');
INSERT INTO `bc_images` VALUES(4, 3, 'item', '3. Aenean commodo ligula eget dolor.', '140740425010.jpg', '194', '259');
INSERT INTO `bc_images` VALUES(5, 4, 'item', 'Aenean commodo ligula eget dolor.', '140740433118.jpg', '225', '225');
INSERT INTO `bc_images` VALUES(6, 4, 'item', 'Aenean commodo ligula eget dolor.', '140740434225.jpg', '225', '225');
INSERT INTO `bc_images` VALUES(7, 4, 'item', 'Aenean commodo ligula eget dolor.', '140740435339.jpg', '193', '261');
INSERT INTO `bc_images` VALUES(8, 5, 'item', 'Aenean commodo ligula eget dolor.', '140740437337.jpg', '194', '260');
INSERT INTO `bc_images` VALUES(9, 5, 'item', 'Aenean commodo ligula eget dolor.', '140740438538.jpg', '214', '235');
INSERT INTO `bc_images` VALUES(10, 5, 'item', 'Aenean commodo ligula eget dolor.', '140740440525.jpg', '225', '225');
INSERT INTO `bc_images` VALUES(11, 6, 'item', 'Aenean commodo ligula eget dolor.', '140740444716.jpg', '237', '212');
INSERT INTO `bc_images` VALUES(12, 6, 'item', 'Aenean commodo ligula eget dolor.', '140740446030.jpg', '183', '275');
INSERT INTO `bc_images` VALUES(13, 7, 'item', 'Aenean commodo ligula eget dolor.', '140740450314.jpg', '204', '247');
INSERT INTO `bc_images` VALUES(14, 7, 'item', 'Aenean commodo ligula eget dolor.', '14074045141.jpg', '195', '259');
INSERT INTO `bc_images` VALUES(15, 7, 'item', 'Aenean commodo ligula eget dolor.', '14074045223.jpg', '188', '269');
INSERT INTO `bc_images` VALUES(16, 8, 'item', 'Aenean commodo ligula eget dolor.', '14074045446.jpg', '225', '225');
INSERT INTO `bc_images` VALUES(17, 8, 'item', 'Aenean commodo ligula eget dolor.', '14074045537.jpg', '217', '232');
INSERT INTO `bc_images` VALUES(18, 8, 'item', 'Aenean commodo ligula eget dolor.', '14074045628.jpg', '213', '237');
INSERT INTO `bc_images` VALUES(19, 9, 'item', 'Aenean commodo ligula eget dolor.', '140740458110.jpg', '194', '259');
INSERT INTO `bc_images` VALUES(20, 9, 'item', 'Aenean commodo ligula eget dolor.', '140740460411.jpg', '300', '377');
INSERT INTO `bc_images` VALUES(21, 9, 'item', 'Aenean commodo ligula eget dolor.', '140740461312.jpg', '216', '233');
INSERT INTO `bc_images` VALUES(22, 10, 'item', 'Aenean commodo ligula eget dolor.', '140740464315.jpg', '225', '225');
INSERT INTO `bc_images` VALUES(23, 10, 'item', 'Aenean commodo ligula eget dolor.', '140740465916.jpg', '180', '280');
INSERT INTO `bc_images` VALUES(24, 10, 'item', 'Aenean commodo ligula eget dolor.', '140740466721.jpg', '211', '239');
INSERT INTO `bc_images` VALUES(25, 11, 'item', 'Aenean commodo ligula eget dolor.', '140740469119.jpg', '200', '252');
INSERT INTO `bc_images` VALUES(26, 11, 'item', 'Aenean commodo ligula eget dolor.', '140740470320.jpg', '245', '206');
INSERT INTO `bc_images` VALUES(27, 12, 'item', 'Aenean commodo ligula eget dolor.', '140740471927.jpg', '225', '225');
INSERT INTO `bc_images` VALUES(28, 12, 'item', 'Aenean commodo ligula eget dolor.', '140740473330.jpg', '206', '245');
INSERT INTO `bc_images` VALUES(29, 12, 'item', 'Aenean commodo ligula eget dolor.', '140740474735.jpg', '229', '220');
INSERT INTO `bc_images` VALUES(30, 3, 'item', '4. Aenean commodo ligula eget dolor.', '140740478417.jpg', '238', '212');
INSERT INTO `bc_images` VALUES(31, 3, 'item', '5. Aenean commodo ligula eget dolor.', '140740479223.jpg', '211', '239');
INSERT INTO `bc_images` VALUES(32, 3, 'item', '6. Aenean commodo ligula eget dolor.', '140740481137.jpg', '194', '260');
INSERT INTO `bc_images` VALUES(33, 3, 'item', '7. Aenean commodo ligula eget dolor.', '14074048267.jpg', '217', '232');
INSERT INTO `bc_images` VALUES(34, 13, 'item', 'Aenean commodo ligula eget dolor.', '14074048561.jpg', '194', '259');
INSERT INTO `bc_images` VALUES(35, 13, 'item', 'Aenean commodo ligula eget dolor.', '14074048652.jpg', '500', '725');
INSERT INTO `bc_images` VALUES(36, 13, 'item', 'Aenean commodo ligula eget dolor.', '14074048733.jpg', '500', '687');
INSERT INTO `bc_images` VALUES(37, 14, 'item', 'Aenean commodo ligula eget dolor.', '14074048937.jpg', '190', '266');
INSERT INTO `bc_images` VALUES(38, 14, 'item', 'Aenean commodo ligula eget dolor.', '14074049066.jpg', '216', '233');
INSERT INTO `bc_images` VALUES(39, 14, 'item', 'Aenean commodo ligula eget dolor.', '14074049154.jpg', '183', '275');
INSERT INTO `bc_images` VALUES(40, 15, 'item', 'Aenean commodo ligula eget dolor.', '14074049388.jpg', '194', '259');
INSERT INTO `bc_images` VALUES(41, 15, 'item', 'Aenean commodo ligula eget dolor.', '14074049452.jpg', '500', '725');
INSERT INTO `bc_images` VALUES(42, 15, 'item', 'Aenean commodo ligula eget dolor.', '14074049547.jpg', '190', '266');
INSERT INTO `bc_images` VALUES(43, 16, 'item', 'Aenean commodo ligula eget dolor.', '140740498210.jpg', '190', '265');
INSERT INTO `bc_images` VALUES(44, 16, 'item', 'Aenean commodo ligula eget dolor.', '140740499611.jpg', '187', '269');
INSERT INTO `bc_images` VALUES(45, 16, 'item', 'Aenean commodo ligula eget dolor.', '14074050056.jpg', '216', '233');
INSERT INTO `bc_images` VALUES(46, 17, 'item', 'Aenean commodo ligula eget dolor.', '140740502812.jpg', '199', '253');
INSERT INTO `bc_images` VALUES(47, 17, 'item', 'Aenean commodo ligula eget dolor.', '14074050366.jpg', '216', '233');
INSERT INTO `bc_images` VALUES(48, 17, 'item', 'Aenean commodo ligula eget dolor.', '14074050464.jpg', '183', '275');
INSERT INTO `bc_images` VALUES(49, 18, 'item', 'Aenean commodo ligula eget dolor.', '140740506419.jpg', '188', '269');
INSERT INTO `bc_images` VALUES(50, 18, 'item', 'Aenean commodo ligula eget dolor.', '140740507214.jpg', '204', '247');
INSERT INTO `bc_images` VALUES(51, 19, 'item', 'Aenean commodo ligula eget dolor.', '140740508715.jpg', '201', '251');
INSERT INTO `bc_images` VALUES(52, 19, 'item', 'Aenean commodo ligula eget dolor.', '140740509820.jpg', '202', '249');
INSERT INTO `bc_images` VALUES(53, 19, 'item', 'Aenean commodo ligula eget dolor.', '140740510514.jpg', '204', '247');
INSERT INTO `bc_images` VALUES(54, 20, 'item', 'Aenean commodo ligula eget dolor.', '140740512317.jpg', '194', '259');
INSERT INTO `bc_images` VALUES(55, 20, 'item', 'Aenean commodo ligula eget dolor.', '140740513320.jpg', '202', '249');
INSERT INTO `bc_images` VALUES(56, 20, 'item', '', '14074051405.jpg', '216', '233');
INSERT INTO `bc_images` VALUES(57, 21, 'item', 'Aenean commodo ligula eget dolor.', '140740518034.jpg', '196', '257');
INSERT INTO `bc_images` VALUES(58, 21, 'item', 'Aenean commodo ligula eget dolor.', '140740518812.jpg', '199', '253');
INSERT INTO `bc_images` VALUES(59, 22, 'item', 'Aenean commodo ligula eget dolor.', '140740520326.jpg', '205', '245');
INSERT INTO `bc_images` VALUES(60, 22, 'item', 'Aenean commodo ligula eget dolor.', '140740521223.jpg', '194', '259');
INSERT INTO `bc_images` VALUES(61, 22, 'item', 'Aenean commodo ligula eget dolor.', '140740522016.jpg', '183', '276');
INSERT INTO `bc_images` VALUES(62, 13, 'item', 'Aenean commodo ligula eget dolor.', '14074052388.jpg', '194', '259');
INSERT INTO `bc_images` VALUES(63, 13, 'item', 'Aenean commodo ligula eget dolor.', '140740525530.jpg', '212', '237');
INSERT INTO `bc_images` VALUES(64, 13, 'item', 'Aenean commodo ligula eget dolor.', '140740526832.jpg', '183', '275');
INSERT INTO `bc_images` VALUES(65, 13, 'item', 'Aenean commodo ligula eget dolor.', '140740527837.jpg', '183', '275');
INSERT INTO `bc_images` VALUES(71, 2, 'feed', 'For Women', '140759317933.jpg', '194', '259');
INSERT INTO `bc_images` VALUES(72, 2, 'feed', 'For Men', '140759319623.jpg', '211', '239');
INSERT INTO `bc_images` VALUES(73, 2, 'feed', 'Like Soccer Star', '14075932212.jpg', '191', '264');
INSERT INTO `bc_images` VALUES(74, 2, 'feed', 'For Kids', '140759323918.jpg', '150', '150');
INSERT INTO `bc_images` VALUES(75, 1, 'feed', 'For Kids', '140759332922.jpg', '336', '336');
INSERT INTO `bc_images` VALUES(76, 1, 'feed', 'For Men', '140759334530.jpg', '206', '245');
INSERT INTO `bc_images` VALUES(77, 1, 'feed', 'For Women', '140759337238.jpg', '211', '239');
INSERT INTO `bc_images` VALUES(78, 3, 'feed', 'For Men Only', '140759343412.jpg', '216', '233');
INSERT INTO `bc_images` VALUES(79, 3, 'feed', 'For Men Only', '140759344617.jpg', '238', '212');
INSERT INTO `bc_images` VALUES(80, 3, 'feed', 'For Men Only', '140759345725.jpg', '225', '225');
INSERT INTO `bc_images` VALUES(81, 3, 'feed', 'For Men', '140759350216.jpg', '237', '212');
INSERT INTO `bc_images` VALUES(82, 4, 'feed', 'For Women', '140759353931.jpg', '194', '259');
INSERT INTO `bc_images` VALUES(83, 4, 'feed', 'For Women Only', '140759355524.jpg', '183', '276');
INSERT INTO `bc_images` VALUES(84, 4, 'feed', 'For Women Only', '140759357839.jpg', '284', '177');
INSERT INTO `bc_images` VALUES(85, 4, 'feed', 'For Women Only', '140759359038.jpg', '211', '239');
INSERT INTO `bc_images` VALUES(86, 5, 'feed', 'For Kids Only', '14075936336.jpg', '199', '253');
INSERT INTO `bc_images` VALUES(87, 5, 'feed', 'For Kids', '14075936598.jpg', '230', '219');
INSERT INTO `bc_images` VALUES(88, 5, 'feed', 'For Kids', '140759366923.jpg', '200', '215');
INSERT INTO `bc_images` VALUES(89, 5, 'feed', 'For Kids', '140759367927.jpg', '225', '300');
INSERT INTO `bc_images` VALUES(90, 5, 'feed', 'For Kids', '140759368711.jpg', '202', '250');
INSERT INTO `bc_images` VALUES(96, 1, 'shop', '1. Phasellus viverra nulla ut metus varius laoreet.', '14080095421.jpeg', '290', '174');
INSERT INTO `bc_images` VALUES(97, 1, 'shop', '2. Curabitur ullamcorper ultricies nisi', '14080095732.jpeg', '275', '183');
INSERT INTO `bc_images` VALUES(98, 1, 'shop', '3. Quisque rutrum', '14080095953.jpeg', '270', '187');
INSERT INTO `bc_images` VALUES(99, 1, 'shop', '4. Curabitur ullamcorper ultricies nisi', '14080096144.jpeg', '259', '194');
INSERT INTO `bc_images` VALUES(100, 1, 'shop', '5. Aenean commodo ligula eget dolor.', '14080096285.jpeg', '275', '183');
INSERT INTO `bc_images` VALUES(101, 23, 'item', '1. Nam pretium turpis et arcu', '140803767722.jpg', '336', '336');
INSERT INTO `bc_images` VALUES(102, 23, 'item', '2. Nam pretium turpis et arcu', '140803769215.jpg', '180', '240');
INSERT INTO `bc_images` VALUES(103, 23, 'item', '3. Nam pretium turpis et arcu', '140803770213.jpg', '180', '240');
INSERT INTO `bc_images` VALUES(104, 23, 'item', '4. Nam pretium turpis et arcu', '140803771119.jpg', '196', '257');
INSERT INTO `bc_images` VALUES(105, 23, 'item', '5. Nam pretium turpis et arcu', '140803772520.jpg', '224', '224');
INSERT INTO `bc_images` VALUES(106, 24, 'item', '1. Nam pretium turpis et arcu. ', '14080377838.jpg', '230', '219');
INSERT INTO `bc_images` VALUES(107, 25, 'item', '1. Nam pretium turpis et arcu. Duis arcu tortor', '140803782331.jpg', '290', '174');
INSERT INTO `bc_images` VALUES(108, 25, 'item', '2. Nam pretium turpis et arcu. Duis arcu tortor', '140803785520.jpg', '224', '224');
INSERT INTO `bc_images` VALUES(109, 25, 'item', '3. Nam pretium turpis et arcu. Duis arcu tortor', '140803786318.jpg', '150', '150');
INSERT INTO `bc_images` VALUES(110, 25, 'item', '4. Nam pretium turpis et arcu. Duis arcu tortor', '140803787221.jpg', '153', '200');
INSERT INTO `bc_images` VALUES(111, 25, 'item', '5. Nam pretium turpis et arcu. Duis arcu tortor', '140803788515.jpg', '180', '240');
INSERT INTO `bc_images` VALUES(112, 26, 'item', '1. Nam pretium turpis et arcu.', '140803794612.jpg', '224', '225');
INSERT INTO `bc_images` VALUES(113, 26, 'item', '2. Nam pretium turpis et arcu.', '14080379606.jpg', '199', '253');
INSERT INTO `bc_images` VALUES(114, 26, 'item', '3. Nam pretium turpis et arcu.', '140803797911.jpg', '202', '250');
INSERT INTO `bc_images` VALUES(115, 26, 'item', '4. Nam pretium turpis et arcu.', '14080379885.jpg', '191', '263');
INSERT INTO `bc_images` VALUES(116, 27, 'item', '1. Nam pretium turpis et arcu.', '14080380809.jpg', '284', '177');
INSERT INTO `bc_images` VALUES(117, 27, 'item', '2. Nam pretium turpis et arcu.', '140803809432.jpg', '183', '275');
INSERT INTO `bc_images` VALUES(118, 27, 'item', '3. Nam pretium turpis et arcu.', '140803810211.jpg', '202', '250');
INSERT INTO `bc_images` VALUES(119, 28, 'item', '1. Nam pretium turpis et arcu. ', '140803815435.jpg', '193', '261');
INSERT INTO `bc_images` VALUES(120, 28, 'item', '2. Nam pretium turpis et arcu. ', '140803816821.jpg', '153', '200');
INSERT INTO `bc_images` VALUES(121, 28, 'item', '3. Nam pretium turpis et arcu. ', '140803817517.jpg', '180', '240');
INSERT INTO `bc_images` VALUES(122, 29, 'item', '1. Nam pretium turpis et arcu.', '140803820730.jpg', '225', '225');
INSERT INTO `bc_images` VALUES(123, 29, 'item', '2. Nam pretium turpis et arcu.', '140803822129.jpg', '195', '259');
INSERT INTO `bc_images` VALUES(124, 29, 'item', '3. Nam pretium turpis et arcu.', '140803823134.jpg', '195', '259');
INSERT INTO `bc_images` VALUES(125, 30, 'item', '1. Nam pretium turpis et arcu.', '140803826828.jpg', '234', '312');
INSERT INTO `bc_images` VALUES(126, 30, 'item', '2. Nam pretium turpis et arcu.', '140803833223.jpg', '200', '215');
INSERT INTO `bc_images` VALUES(127, 30, 'item', '3. Nam pretium turpis et arcu.', '14080383428.jpg', '230', '219');
INSERT INTO `bc_images` VALUES(128, 31, 'item', '1. Nam pretium turpis et arcu. ', '140803839911.jpg', '202', '250');
INSERT INTO `bc_images` VALUES(129, 31, 'item', '2. Nam pretium turpis et arcu. ', '140803841228.jpg', '234', '312');
INSERT INTO `bc_images` VALUES(130, 31, 'item', '3. Nam pretium turpis et arcu. ', '140803841913.jpg', '180', '240');
INSERT INTO `bc_images` VALUES(131, 32, 'item', '1. Nam pretium turpis et arcu. ', '140803845428.jpg', '234', '312');
INSERT INTO `bc_images` VALUES(132, 32, 'item', '2. Nam pretium turpis et arcu. ', '140803846613.jpg', '180', '240');
INSERT INTO `bc_images` VALUES(133, 32, 'item', '3. Nam pretium turpis et arcu. ', '140803848019.jpg', '196', '257');
INSERT INTO `bc_images` VALUES(134, 33, 'item', '1. Nam pretium turpis et arcu.', '140803850918.jpg', '150', '150');
INSERT INTO `bc_images` VALUES(135, 33, 'item', '2. Nam pretium turpis et arcu.', '140803851919.jpg', '196', '257');
INSERT INTO `bc_images` VALUES(136, 33, 'item', '3. Nam pretium turpis et arcu.', '14080385299.jpg', '284', '177');
INSERT INTO `bc_images` VALUES(137, 34, 'item', '1. Curabitur ligula sapien, tincidunt non', '140803860216.jpg', '237', '212');
INSERT INTO `bc_images` VALUES(138, 34, 'item', '2. Curabitur ligula sapien, tincidunt non', '140803861622.jpg', '182', '277');
INSERT INTO `bc_images` VALUES(139, 34, 'item', '3. Curabitur ligula sapien, tincidunt non', '140803862613.jpg', '189', '266');
INSERT INTO `bc_images` VALUES(140, 34, 'item', '4. Curabitur ligula sapien, tincidunt non', '140803864024.jpg', '217', '232');
INSERT INTO `bc_images` VALUES(141, 35, 'item', '1. Curabitur ligula sapien, tincidunt non', '140803867431.jpg', '225', '225');
INSERT INTO `bc_images` VALUES(142, 35, 'item', '1. Curabitur ligula sapien, tincidunt non', '14080386923.jpg', '272', '185');
INSERT INTO `bc_images` VALUES(143, 35, 'item', '3. Curabitur ligula sapien, tincidunt non', '140803870411.jpg', '236', '213');
INSERT INTO `bc_images` VALUES(144, 36, 'item', '1. Curabitur ligula sapien, tincidunt non', '14080387481.jpg', '209', '238');
INSERT INTO `bc_images` VALUES(145, 36, 'item', '2. Curabitur ligula sapien, tincidunt non', '140803876121.jpg', '208', '242');
INSERT INTO `bc_images` VALUES(146, 36, 'item', '3. Curabitur ligula sapien, tincidunt non', '140803876813.jpg', '189', '266');
INSERT INTO `bc_images` VALUES(147, 37, 'item', '1. Curabitur ligula sapien', '140803880717.jpg', '292', '172');
INSERT INTO `bc_images` VALUES(148, 37, 'item', '2. Curabitur ligula sapien', '140803882212.jpg', '183', '276');
INSERT INTO `bc_images` VALUES(149, 37, 'item', '3. Curabitur ligula sapien', '140803883214.jpg', '258', '195');
INSERT INTO `bc_images` VALUES(150, 38, 'item', '1. Curabitur ligula sapien', '140803887219.jpg', '201', '250');
INSERT INTO `bc_images` VALUES(151, 38, 'item', '2. Curabitur ligula sapien', '140803888321.jpg', '208', '242');
INSERT INTO `bc_images` VALUES(152, 38, 'item', '3. Curabitur ligula sapien', '140803889218.jpg', '206', '245');
INSERT INTO `bc_images` VALUES(153, 39, 'item', '1. Curabitur ligula sapien', '140803896737.jpg', '194', '259');
INSERT INTO `bc_images` VALUES(154, 39, 'item', '2. Curabitur ligula sapien', '140803898116.jpg', '237', '212');
INSERT INTO `bc_images` VALUES(155, 39, 'item', '3. Curabitur ligula sapien', '14080389877.jpg', '194', '259');
INSERT INTO `bc_images` VALUES(156, 40, 'item', '1. Curabitur ligula sapien, tincidunt non', '140803902540.jpg', '290', '174');
INSERT INTO `bc_images` VALUES(157, 40, 'item', '2. Curabitur ligula sapien, tincidunt non', '140803903614.jpg', '258', '195');
INSERT INTO `bc_images` VALUES(158, 40, 'item', '3. Curabitur ligula sapien, tincidunt non', '140803904424.jpg', '217', '232');
INSERT INTO `bc_images` VALUES(159, 41, 'item', '1. Curabitur ligula sapien, tincidunt non', '140803907833.jpg', '256', '197');
INSERT INTO `bc_images` VALUES(160, 41, 'item', '2. Curabitur ligula sapien, tincidunt non', '140803908720.jpg', '203', '248');
INSERT INTO `bc_images` VALUES(161, 41, 'item', '3. Curabitur ligula sapien, tincidunt non', '140803909640.jpg', '290', '174');
INSERT INTO `bc_images` VALUES(162, 42, 'item', '1. Curabitur ligula sapien,', '140803912114.jpg', '258', '195');
INSERT INTO `bc_images` VALUES(163, 42, 'item', '2. Curabitur ligula sapien,', '140803913326.jpg', '259', '194');
INSERT INTO `bc_images` VALUES(164, 42, 'item', '3. Curabitur ligula sapien,', '140803914215.jpg', '299', '168');
INSERT INTO `bc_images` VALUES(165, 1, 'shop', 'Etiam sit amet orci eget eros faucibus tincidunt.', '140975142815.jpeg', '160', '240');

-- --------------------------------------------------------

--
-- Table structure for table `bc_inquiries`
--

CREATE TABLE `bc_inquiries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `message` text CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `bc_inquiries`
--

INSERT INTO `bc_inquiries` VALUES(1, 3, 'Han', 'Pphmit@gmail.com', 'Inquiry Test1', 1, '2014-08-12 00:20:10', NULL);
INSERT INTO `bc_inquiries` VALUES(2, 3, 'Han', 'Han@gmail.com', 'Hi this is testing from iPod', 1, '2014-08-21 14:55:11', NULL);
INSERT INTO `bc_inquiries` VALUES(3, 3, 'iPad User', 'User@gmail.com', 'Send inquiry from iPad', 1, '2014-08-21 17:27:51', NULL);
INSERT INTO `bc_inquiries` VALUES(4, 4, 'Han', 'Han@gmail.com', 'Sent inquiry from iPad', 1, '2014-08-21 19:16:31', NULL);
INSERT INTO `bc_inquiries` VALUES(5, 15, 'han', 'han@gmail.com', 'inquiry submit from android', 1, '2014-08-21 20:09:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bc_items`
--

CREATE TABLE `bc_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `price` text CHARACTER SET utf8 NOT NULL,
  `is_publish` int(11) NOT NULL DEFAULT '0',
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `bc_items`
--

INSERT INTO `bc_items` VALUES(3, 1, 'No-1', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$15', 1, '2014-08-07 16:40:09');
INSERT INTO `bc_items` VALUES(4, 1, 'No-2', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$15', 1, '2014-08-07 16:41:06');
INSERT INTO `bc_items` VALUES(5, 1, 'No-3', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$20', 1, '2014-08-07 16:43:00');
INSERT INTO `bc_items` VALUES(6, 1, 'No-4', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$30', 1, '2014-08-07 16:43:25');
INSERT INTO `bc_items` VALUES(7, 1, 'No-5', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$20', 1, '2014-08-07 16:43:42');
INSERT INTO `bc_items` VALUES(8, 1, 'No-6', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$10', 1, '2014-08-07 16:44:05');
INSERT INTO `bc_items` VALUES(9, 1, 'No-7', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$30', 1, '2014-08-07 16:44:27');
INSERT INTO `bc_items` VALUES(10, 1, 'No-8', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$20', 1, '2014-08-07 16:44:52');
INSERT INTO `bc_items` VALUES(11, 1, 'No-9', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$15', 1, '2014-08-07 16:45:26');
INSERT INTO `bc_items` VALUES(12, 1, 'No-10', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$15', 1, '2014-08-07 16:46:21');
INSERT INTO `bc_items` VALUES(13, 2, 'No-11', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$10', 1, '2014-08-07 16:50:03');
INSERT INTO `bc_items` VALUES(14, 2, 'No-12', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$20', 1, '2014-08-07 16:50:22');
INSERT INTO `bc_items` VALUES(15, 2, 'No-13', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$30', 1, '2014-08-07 16:50:39');
INSERT INTO `bc_items` VALUES(16, 2, 'No-14', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$50', 1, '2014-08-07 16:50:59');
INSERT INTO `bc_items` VALUES(17, 2, 'No-15', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$40', 1, '2014-08-07 16:51:18');
INSERT INTO `bc_items` VALUES(18, 2, 'No-16', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$20', 1, '2014-08-07 16:51:50');
INSERT INTO `bc_items` VALUES(19, 2, 'No-17', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$30', 1, '2014-08-07 16:52:21');
INSERT INTO `bc_items` VALUES(20, 2, 'No-18', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$40', 1, '2014-08-07 16:52:42');
INSERT INTO `bc_items` VALUES(21, 2, 'No-19', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$50', 1, '2014-08-07 16:53:01');
INSERT INTO `bc_items` VALUES(22, 2, 'No-20', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\nmus.', '$50', 1, '2014-08-07 16:53:41');
INSERT INTO `bc_items` VALUES(23, 3, 'No-21', 'Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing.', '$4', 1, '2014-08-15 01:34:37');
INSERT INTO `bc_items` VALUES(24, 3, 'No-22', 'Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing.', '$3', 1, '2014-08-15 01:36:23');
INSERT INTO `bc_items` VALUES(25, 3, 'No-23', 'Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing.', '$6', 1, '2014-08-15 01:37:03');
INSERT INTO `bc_items` VALUES(26, 3, 'No-24', 'Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing.', '$2', 1, '2014-08-15 01:39:06');
INSERT INTO `bc_items` VALUES(27, 3, 'No-25', 'Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing.', '$3', 1, '2014-08-15 01:41:20');
INSERT INTO `bc_items` VALUES(28, 3, 'No-26', 'Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing.', '$5', 1, '2014-08-15 01:42:34');
INSERT INTO `bc_items` VALUES(29, 3, 'No-27', 'Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing.', '$6', 1, '2014-08-15 01:43:27');
INSERT INTO `bc_items` VALUES(30, 3, 'No-28', 'Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing.', '$3', 1, '2014-08-15 01:44:28');
INSERT INTO `bc_items` VALUES(31, 3, 'No-29', 'Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing.', '$2', 1, '2014-08-15 01:46:39');
INSERT INTO `bc_items` VALUES(32, 3, 'No-30', 'Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing.', '$2', 1, '2014-08-15 01:47:34');
INSERT INTO `bc_items` VALUES(33, 3, 'No-31', 'Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing.', '$2', 1, '2014-08-15 01:48:29');
INSERT INTO `bc_items` VALUES(34, 4, 'No-32', 'Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu.\nPhasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit.', '$22', 1, '2014-08-15 01:50:02');
INSERT INTO `bc_items` VALUES(35, 4, 'No-33', 'Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu.\nPhasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit.', '$23', 1, '2014-08-15 01:51:14');
INSERT INTO `bc_items` VALUES(36, 4, 'No-34', 'Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu.\nPhasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit.', '$24', 1, '2014-08-15 01:52:28');
INSERT INTO `bc_items` VALUES(37, 4, 'No-35', 'Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu.\nPhasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit.', '$25', 1, '2014-08-15 01:53:27');
INSERT INTO `bc_items` VALUES(38, 4, 'No-36', 'Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu.\nPhasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit.', '$25', 1, '2014-08-15 01:54:32');
INSERT INTO `bc_items` VALUES(39, 4, 'No-37', 'Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu.\nPhasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. ', '$26', 1, '2014-08-15 01:56:07');
INSERT INTO `bc_items` VALUES(40, 4, 'No-38', 'Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu.\nPhasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. ', '$22', 1, '2014-08-15 01:57:05');
INSERT INTO `bc_items` VALUES(41, 4, 'No-39', 'Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu.\nPhasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. ', '$33', 1, '2014-08-15 01:57:58');
INSERT INTO `bc_items` VALUES(42, 4, 'No-40', 'Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu.\nPhasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. ', '$22', 1, '2014-08-15 01:58:41');

-- --------------------------------------------------------

--
-- Table structure for table `bc_likes`
--

CREATE TABLE `bc_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `appuser_id` int(11) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `bc_likes`
--

INSERT INTO `bc_likes` VALUES(5, 3, 1, '2014-08-09 20:41:42');
INSERT INTO `bc_likes` VALUES(6, 4, 1, '2014-08-14 23:54:44');
INSERT INTO `bc_likes` VALUES(7, 15, 1, '2014-08-21 15:28:37');
INSERT INTO `bc_likes` VALUES(8, 17, 1, '2014-08-21 16:06:57');
INSERT INTO `bc_likes` VALUES(9, 14, 2, '2014-08-21 19:18:28');
INSERT INTO `bc_likes` VALUES(10, 18, 2, '2014-08-21 19:30:16');
INSERT INTO `bc_likes` VALUES(11, 14, 6, '2014-08-21 20:15:40');

-- --------------------------------------------------------

--
-- Table structure for table `bc_reviews`
--

CREATE TABLE `bc_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `appuser_id` int(11) NOT NULL,
  `review` text CHARACTER SET utf8 NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `bc_reviews`
--

INSERT INTO `bc_reviews` VALUES(1, 3, 1, 'Test', 1, '2014-08-09 19:25:11', NULL);
INSERT INTO `bc_reviews` VALUES(2, 3, 1, 'Test2', 1, '2014-08-09 19:28:12', NULL);
INSERT INTO `bc_reviews` VALUES(3, 13, 1, 'Hair style is very nice.', 1, '2014-08-14 21:45:43', NULL);
INSERT INTO `bc_reviews` VALUES(4, 13, 1, 'Cool app!', 1, '2014-08-14 21:47:12', NULL);
INSERT INTO `bc_reviews` VALUES(5, 13, 1, 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\rmus.', 1, '2014-08-14 21:50:28', NULL);
INSERT INTO `bc_reviews` VALUES(6, 13, 1, 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus\rmus.', 1, '2014-08-14 21:53:33', NULL);
INSERT INTO `bc_reviews` VALUES(7, 13, 1, 'Aenean commodo ligula eget dolor. ', 1, '2014-08-14 22:09:10', NULL);
INSERT INTO `bc_reviews` VALUES(8, 13, 1, 'Aenean commodo ligula eget dolor. ', 1, '2014-08-14 22:11:28', NULL);
INSERT INTO `bc_reviews` VALUES(9, 13, 1, 'Aenean commodo ligula eget dolor. ', 1, '2014-08-14 22:19:53', NULL);
INSERT INTO `bc_reviews` VALUES(10, 14, 1, 'Aenean commodo ligula eget dolor. ', 1, '2014-08-14 22:23:35', NULL);
INSERT INTO `bc_reviews` VALUES(11, 14, 1, 'Aenean commodo ligula eget dolor. ', 1, '2014-08-14 22:25:12', NULL);
INSERT INTO `bc_reviews` VALUES(12, 4, 1, 'Aenean commodo ligula eget dolor. ', 1, '2014-08-14 23:28:26', NULL);
INSERT INTO `bc_reviews` VALUES(13, 4, 1, 'Aenean commodo ligula eget dolor. ', 1, '2014-08-14 23:30:30', NULL);
INSERT INTO `bc_reviews` VALUES(14, 4, 1, 'Aenean commodo ligula eget dolor. ', 1, '2014-08-14 23:34:06', NULL);
INSERT INTO `bc_reviews` VALUES(15, 4, 1, 'Aenean commodo ligula eget dolor. ', 1, '2014-08-14 23:38:55', NULL);
INSERT INTO `bc_reviews` VALUES(16, 4, 1, 'Aenean commodo ligula eget dolor. ', 1, '2014-08-14 23:40:00', NULL);
INSERT INTO `bc_reviews` VALUES(17, 4, 1, 'Aenean commodo ligula eget dolor. ', 1, '2014-08-14 23:50:31', NULL);
INSERT INTO `bc_reviews` VALUES(18, 3, 1, 'Review submit from iPod', 1, '2014-08-21 14:59:21', NULL);
INSERT INTO `bc_reviews` VALUES(19, 14, 1, 'Testing from simulator', 1, '2014-08-21 15:06:06', NULL);
INSERT INTO `bc_reviews` VALUES(20, 14, 1, 'Hello testing from simulator', 1, '2014-08-21 15:16:19', NULL);
INSERT INTO `bc_reviews` VALUES(21, 15, 1, 'Testing from iPod', 1, '2014-08-21 15:25:29', NULL);
INSERT INTO `bc_reviews` VALUES(22, 15, 1, 'Hello testing again from iPod ', 1, '2014-08-21 15:27:15', NULL);
INSERT INTO `bc_reviews` VALUES(23, 5, 4, 'Submit review after register user', 1, '2014-08-21 17:14:49', NULL);
INSERT INTO `bc_reviews` VALUES(24, 15, 4, 'Review testing again.', 1, '2014-08-21 17:20:18', NULL);
INSERT INTO `bc_reviews` VALUES(25, 4, 2, 'Review submit from iPad', 1, '2014-08-21 19:17:47', NULL);
INSERT INTO `bc_reviews` VALUES(26, 15, 6, 'review submit from android.', 1, '2014-08-21 20:11:23', NULL);
INSERT INTO `bc_reviews` VALUES(27, 18, 9, 'Review testing for version 1.1.0', 1, '2014-09-11 00:21:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bc_shop_info`
--

CREATE TABLE `bc_shop_info` (
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `phone` text CHARACTER SET utf8 NOT NULL,
  `address` text CHARACTER SET utf8 NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bc_shop_info`
--

INSERT INTO `bc_shop_info` VALUES('Panacea Soft', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculusmus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. ', '+95 9312389013', 'No-987, Pagoda Road, Yangon, Myanmar', '2014-07-30 21:48:30');

-- --------------------------------------------------------

--
-- Table structure for table `bc_touches`
--

CREATE TABLE `bc_touches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `appuser_id` int(11) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=242 ;

--
-- Dumping data for table `bc_touches`
--

INSERT INTO `bc_touches` VALUES(1, 3, 1, '2014-08-09 20:38:30');
INSERT INTO `bc_touches` VALUES(2, 3, 1, '2014-08-09 20:39:07');
INSERT INTO `bc_touches` VALUES(3, 3, 1, '2014-08-09 20:39:28');
INSERT INTO `bc_touches` VALUES(4, 3, 1, '2014-08-09 20:39:47');
INSERT INTO `bc_touches` VALUES(5, 3, 1, '2014-08-09 20:40:51');
INSERT INTO `bc_touches` VALUES(6, 3, 1, '2014-08-09 20:41:40');
INSERT INTO `bc_touches` VALUES(7, 3, 1, '2014-08-09 21:29:36');
INSERT INTO `bc_touches` VALUES(8, 3, 1, '2014-08-09 21:33:59');
INSERT INTO `bc_touches` VALUES(9, 3, 1, '2014-08-09 21:36:11');
INSERT INTO `bc_touches` VALUES(10, 3, 1, '2014-08-09 21:48:36');
INSERT INTO `bc_touches` VALUES(11, 3, 1, '2014-08-09 21:57:13');
INSERT INTO `bc_touches` VALUES(12, 3, 1, '2014-08-10 15:54:28');
INSERT INTO `bc_touches` VALUES(13, 3, 1, '2014-08-10 16:17:44');
INSERT INTO `bc_touches` VALUES(14, 3, 1, '2014-08-10 16:18:58');
INSERT INTO `bc_touches` VALUES(15, 3, 1, '2014-08-10 16:20:00');
INSERT INTO `bc_touches` VALUES(16, 3, 1, '2014-08-10 16:25:55');
INSERT INTO `bc_touches` VALUES(17, 3, 1, '2014-08-10 16:28:39');
INSERT INTO `bc_touches` VALUES(18, 3, 1, '2014-08-10 16:34:21');
INSERT INTO `bc_touches` VALUES(19, 3, 1, '2014-08-10 16:35:04');
INSERT INTO `bc_touches` VALUES(20, 3, 1, '2014-08-10 16:38:34');
INSERT INTO `bc_touches` VALUES(21, 4, 1, '2014-08-10 20:45:44');
INSERT INTO `bc_touches` VALUES(22, 13, 1, '2014-08-10 21:09:15');
INSERT INTO `bc_touches` VALUES(23, 6, 1, '2014-08-11 02:00:35');
INSERT INTO `bc_touches` VALUES(24, 3, 1, '2014-08-12 00:59:48');
INSERT INTO `bc_touches` VALUES(25, 3, 1, '2014-08-12 01:01:19');
INSERT INTO `bc_touches` VALUES(26, 4, 1, '2014-08-12 23:53:17');
INSERT INTO `bc_touches` VALUES(27, 3, 1, '2014-08-13 06:22:22');
INSERT INTO `bc_touches` VALUES(28, 3, 1, '2014-08-13 06:24:53');
INSERT INTO `bc_touches` VALUES(29, 3, 1, '2014-08-13 06:25:57');
INSERT INTO `bc_touches` VALUES(30, 3, 1, '2014-08-13 17:03:42');
INSERT INTO `bc_touches` VALUES(31, 3, 1, '2014-08-13 18:08:03');
INSERT INTO `bc_touches` VALUES(32, 3, 1, '2014-08-13 18:37:50');
INSERT INTO `bc_touches` VALUES(33, 3, 1, '2014-08-13 20:50:24');
INSERT INTO `bc_touches` VALUES(34, 3, 1, '2014-08-13 20:52:40');
INSERT INTO `bc_touches` VALUES(35, 3, 1, '2014-08-13 20:54:40');
INSERT INTO `bc_touches` VALUES(36, 3, 1, '2014-08-13 20:57:01');
INSERT INTO `bc_touches` VALUES(37, 3, 1, '2014-08-13 21:00:47');
INSERT INTO `bc_touches` VALUES(38, 3, 1, '2014-08-13 21:02:35');
INSERT INTO `bc_touches` VALUES(39, 3, 1, '2014-08-13 21:05:01');
INSERT INTO `bc_touches` VALUES(40, 3, 1, '2014-08-13 21:09:17');
INSERT INTO `bc_touches` VALUES(41, 3, 1, '2014-08-13 21:11:15');
INSERT INTO `bc_touches` VALUES(42, 3, 1, '2014-08-13 21:13:38');
INSERT INTO `bc_touches` VALUES(43, 3, 1, '2014-08-13 21:37:24');
INSERT INTO `bc_touches` VALUES(44, 3, 1, '2014-08-13 23:43:45');
INSERT INTO `bc_touches` VALUES(45, 3, 1, '2014-08-13 23:46:48');
INSERT INTO `bc_touches` VALUES(46, 3, 1, '2014-08-14 00:05:15');
INSERT INTO `bc_touches` VALUES(47, 3, 1, '2014-08-14 00:07:50');
INSERT INTO `bc_touches` VALUES(48, 3, 1, '2014-08-14 00:12:22');
INSERT INTO `bc_touches` VALUES(49, 3, 1, '2014-08-14 00:15:12');
INSERT INTO `bc_touches` VALUES(50, 3, 1, '2014-08-14 00:17:41');
INSERT INTO `bc_touches` VALUES(51, 3, 1, '2014-08-14 00:37:18');
INSERT INTO `bc_touches` VALUES(52, 3, 1, '2014-08-14 01:03:16');
INSERT INTO `bc_touches` VALUES(53, 3, 1, '2014-08-14 01:44:17');
INSERT INTO `bc_touches` VALUES(54, 3, 1, '2014-08-14 01:52:55');
INSERT INTO `bc_touches` VALUES(55, 3, 1, '2014-08-14 01:54:16');
INSERT INTO `bc_touches` VALUES(56, 3, 1, '2014-08-14 01:56:34');
INSERT INTO `bc_touches` VALUES(57, 3, 1, '2014-08-14 02:00:16');
INSERT INTO `bc_touches` VALUES(58, 3, 1, '2014-08-14 02:03:40');
INSERT INTO `bc_touches` VALUES(59, 3, 1, '2014-08-14 02:05:45');
INSERT INTO `bc_touches` VALUES(60, 3, 1, '2014-08-14 02:06:34');
INSERT INTO `bc_touches` VALUES(61, 3, 1, '2014-08-14 02:12:12');
INSERT INTO `bc_touches` VALUES(62, 3, 1, '2014-08-14 02:13:35');
INSERT INTO `bc_touches` VALUES(63, 3, 1, '2014-08-14 02:18:33');
INSERT INTO `bc_touches` VALUES(64, 3, 1, '2014-08-14 02:22:52');
INSERT INTO `bc_touches` VALUES(65, 3, 1, '2014-08-14 02:25:31');
INSERT INTO `bc_touches` VALUES(66, 3, 1, '2014-08-14 02:26:31');
INSERT INTO `bc_touches` VALUES(67, 3, 1, '2014-08-14 02:27:30');
INSERT INTO `bc_touches` VALUES(68, 3, 1, '2014-08-14 02:30:07');
INSERT INTO `bc_touches` VALUES(69, 3, 1, '2014-08-14 02:35:28');
INSERT INTO `bc_touches` VALUES(70, 3, 1, '2014-08-14 02:38:02');
INSERT INTO `bc_touches` VALUES(71, 3, 1, '2014-08-14 02:46:28');
INSERT INTO `bc_touches` VALUES(72, 3, 1, '2014-08-14 02:47:38');
INSERT INTO `bc_touches` VALUES(73, 3, 1, '2014-08-14 02:48:42');
INSERT INTO `bc_touches` VALUES(74, 3, 1, '2014-08-14 02:49:44');
INSERT INTO `bc_touches` VALUES(75, 3, 1, '2014-08-14 02:51:15');
INSERT INTO `bc_touches` VALUES(76, 3, 1, '2014-08-14 03:17:27');
INSERT INTO `bc_touches` VALUES(77, 3, 1, '2014-08-14 03:19:42');
INSERT INTO `bc_touches` VALUES(78, 3, 1, '2014-08-14 03:20:53');
INSERT INTO `bc_touches` VALUES(79, 3, 1, '2014-08-14 03:23:25');
INSERT INTO `bc_touches` VALUES(80, 3, 1, '2014-08-14 03:24:54');
INSERT INTO `bc_touches` VALUES(81, 3, 1, '2014-08-14 03:26:33');
INSERT INTO `bc_touches` VALUES(82, 3, 1, '2014-08-14 03:35:46');
INSERT INTO `bc_touches` VALUES(83, 3, 1, '2014-08-14 03:36:13');
INSERT INTO `bc_touches` VALUES(84, 3, 1, '2014-08-14 04:26:53');
INSERT INTO `bc_touches` VALUES(85, 3, 1, '2014-08-14 04:28:32');
INSERT INTO `bc_touches` VALUES(86, 3, 1, '2014-08-14 04:30:54');
INSERT INTO `bc_touches` VALUES(87, 3, 1, '2014-08-14 04:41:32');
INSERT INTO `bc_touches` VALUES(88, 3, 1, '2014-08-14 04:42:31');
INSERT INTO `bc_touches` VALUES(89, 3, 1, '2014-08-14 04:43:50');
INSERT INTO `bc_touches` VALUES(90, 3, 1, '2014-08-14 04:45:53');
INSERT INTO `bc_touches` VALUES(91, 3, 1, '2014-08-14 04:48:11');
INSERT INTO `bc_touches` VALUES(92, 3, 1, '2014-08-14 04:49:53');
INSERT INTO `bc_touches` VALUES(93, 3, 1, '2014-08-14 04:50:45');
INSERT INTO `bc_touches` VALUES(94, 3, 1, '2014-08-14 04:51:51');
INSERT INTO `bc_touches` VALUES(95, 3, 1, '2014-08-14 04:53:57');
INSERT INTO `bc_touches` VALUES(96, 3, 1, '2014-08-14 04:55:19');
INSERT INTO `bc_touches` VALUES(97, 3, 1, '2014-08-14 04:57:45');
INSERT INTO `bc_touches` VALUES(98, 3, 1, '2014-08-14 05:06:24');
INSERT INTO `bc_touches` VALUES(99, 3, 1, '2014-08-14 05:07:45');
INSERT INTO `bc_touches` VALUES(100, 3, 1, '2014-08-14 05:08:34');
INSERT INTO `bc_touches` VALUES(101, 3, 1, '2014-08-14 05:10:03');
INSERT INTO `bc_touches` VALUES(102, 3, 1, '2014-08-14 05:11:28');
INSERT INTO `bc_touches` VALUES(103, 3, 1, '2014-08-14 16:23:45');
INSERT INTO `bc_touches` VALUES(104, 3, 1, '2014-08-14 16:25:31');
INSERT INTO `bc_touches` VALUES(105, 3, 1, '2014-08-14 16:25:38');
INSERT INTO `bc_touches` VALUES(106, 3, 1, '2014-08-14 16:26:37');
INSERT INTO `bc_touches` VALUES(107, 3, 1, '2014-08-14 16:32:00');
INSERT INTO `bc_touches` VALUES(108, 3, 1, '2014-08-14 16:33:05');
INSERT INTO `bc_touches` VALUES(109, 3, 1, '2014-08-14 16:39:47');
INSERT INTO `bc_touches` VALUES(110, 3, 1, '2014-08-14 16:41:09');
INSERT INTO `bc_touches` VALUES(111, 3, 1, '2014-08-14 16:43:05');
INSERT INTO `bc_touches` VALUES(112, 3, 1, '2014-08-14 16:47:53');
INSERT INTO `bc_touches` VALUES(113, 3, 1, '2014-08-14 16:52:00');
INSERT INTO `bc_touches` VALUES(114, 3, 1, '2014-08-14 17:02:11');
INSERT INTO `bc_touches` VALUES(115, 3, 1, '2014-08-14 17:39:03');
INSERT INTO `bc_touches` VALUES(116, 3, 1, '2014-08-14 17:50:00');
INSERT INTO `bc_touches` VALUES(117, 3, 1, '2014-08-14 17:52:03');
INSERT INTO `bc_touches` VALUES(118, 3, 1, '2014-08-14 20:03:36');
INSERT INTO `bc_touches` VALUES(119, 3, 1, '2014-08-14 20:52:22');
INSERT INTO `bc_touches` VALUES(120, 3, 1, '2014-08-14 20:54:01');
INSERT INTO `bc_touches` VALUES(121, 3, 1, '2014-08-14 20:55:11');
INSERT INTO `bc_touches` VALUES(122, 13, 1, '2014-08-14 21:44:39');
INSERT INTO `bc_touches` VALUES(123, 13, 1, '2014-08-14 21:46:59');
INSERT INTO `bc_touches` VALUES(124, 13, 1, '2014-08-14 21:49:55');
INSERT INTO `bc_touches` VALUES(125, 13, 1, '2014-08-14 21:53:16');
INSERT INTO `bc_touches` VALUES(126, 13, 1, '2014-08-14 21:53:56');
INSERT INTO `bc_touches` VALUES(127, 3, 1, '2014-08-14 21:54:54');
INSERT INTO `bc_touches` VALUES(128, 13, 1, '2014-08-14 21:55:02');
INSERT INTO `bc_touches` VALUES(129, 13, 1, '2014-08-14 21:56:58');
INSERT INTO `bc_touches` VALUES(130, 13, 1, '2014-08-14 22:02:38');
INSERT INTO `bc_touches` VALUES(131, 13, 1, '2014-08-14 22:08:18');
INSERT INTO `bc_touches` VALUES(132, 13, 1, '2014-08-14 22:11:08');
INSERT INTO `bc_touches` VALUES(133, 13, 1, '2014-08-14 22:18:27');
INSERT INTO `bc_touches` VALUES(134, 14, 1, '2014-08-14 22:23:18');
INSERT INTO `bc_touches` VALUES(135, 14, 1, '2014-08-14 22:24:52');
INSERT INTO `bc_touches` VALUES(136, 4, 1, '2014-08-14 23:27:56');
INSERT INTO `bc_touches` VALUES(137, 4, 1, '2014-08-14 23:30:20');
INSERT INTO `bc_touches` VALUES(138, 4, 1, '2014-08-14 23:33:51');
INSERT INTO `bc_touches` VALUES(139, 4, 1, '2014-08-14 23:38:46');
INSERT INTO `bc_touches` VALUES(140, 4, 1, '2014-08-14 23:39:53');
INSERT INTO `bc_touches` VALUES(141, 3, 1, '2014-08-14 23:50:18');
INSERT INTO `bc_touches` VALUES(142, 4, 1, '2014-08-14 23:50:24');
INSERT INTO `bc_touches` VALUES(143, 4, 1, '2014-08-14 23:54:40');
INSERT INTO `bc_touches` VALUES(144, 13, 1, '2014-08-15 19:59:04');
INSERT INTO `bc_touches` VALUES(145, 3, 1, '2014-08-16 21:53:36');
INSERT INTO `bc_touches` VALUES(146, 34, 1, '2014-08-17 15:58:42');
INSERT INTO `bc_touches` VALUES(147, 23, 1, '2014-08-17 16:00:00');
INSERT INTO `bc_touches` VALUES(148, 19, 1, '2014-08-17 16:02:30');
INSERT INTO `bc_touches` VALUES(149, 5, 1, '2014-08-17 16:03:06');
INSERT INTO `bc_touches` VALUES(150, 3, 1, '2014-08-17 16:04:44');
INSERT INTO `bc_touches` VALUES(151, 3, 1, '2014-08-17 19:28:35');
INSERT INTO `bc_touches` VALUES(152, 3, 1, '2014-08-17 19:40:03');
INSERT INTO `bc_touches` VALUES(153, 14, 1, '2014-08-17 19:41:11');
INSERT INTO `bc_touches` VALUES(154, 14, 1, '2014-08-21 15:11:10');
INSERT INTO `bc_touches` VALUES(155, 14, 1, '2014-08-21 15:16:00');
INSERT INTO `bc_touches` VALUES(156, 15, 1, '2014-08-21 15:25:12');
INSERT INTO `bc_touches` VALUES(157, 15, 1, '2014-08-21 15:26:49');
INSERT INTO `bc_touches` VALUES(158, 5, 1, '2014-08-21 15:31:02');
INSERT INTO `bc_touches` VALUES(159, 5, 1, '2014-08-21 15:31:39');
INSERT INTO `bc_touches` VALUES(160, 17, 1, '2014-08-21 15:47:43');
INSERT INTO `bc_touches` VALUES(161, 16, 1, '2014-08-21 15:49:39');
INSERT INTO `bc_touches` VALUES(162, 14, 1, '2014-08-21 15:51:42');
INSERT INTO `bc_touches` VALUES(163, 17, 1, '2014-08-21 16:06:23');
INSERT INTO `bc_touches` VALUES(164, 15, 4, '2014-08-21 17:18:58');
INSERT INTO `bc_touches` VALUES(165, 14, 2, '2014-08-21 19:18:26');
INSERT INTO `bc_touches` VALUES(166, 18, 2, '2014-08-21 19:20:02');
INSERT INTO `bc_touches` VALUES(167, 18, 2, '2014-08-21 19:30:13');
INSERT INTO `bc_touches` VALUES(168, 6, 5, '2014-08-21 19:41:57');
INSERT INTO `bc_touches` VALUES(169, 3, 5, '2014-08-21 19:48:24');
INSERT INTO `bc_touches` VALUES(170, 4, 5, '2014-08-21 19:48:57');
INSERT INTO `bc_touches` VALUES(171, 5, 5, '2014-08-21 19:50:15');
INSERT INTO `bc_touches` VALUES(172, 15, 5, '2014-08-21 19:52:37');
INSERT INTO `bc_touches` VALUES(173, 4, 1, '2014-08-21 19:54:03');
INSERT INTO `bc_touches` VALUES(174, 13, 6, '2014-08-21 19:57:31');
INSERT INTO `bc_touches` VALUES(175, 14, 6, '2014-08-21 20:15:20');
INSERT INTO `bc_touches` VALUES(176, 5, 6, '2014-08-21 20:17:22');
INSERT INTO `bc_touches` VALUES(177, 3, 7, '2014-08-21 21:15:09');
INSERT INTO `bc_touches` VALUES(178, 3, 7, '2014-08-21 21:18:44');
INSERT INTO `bc_touches` VALUES(179, 3, 7, '2014-08-21 21:21:49');
INSERT INTO `bc_touches` VALUES(180, 3, 7, '2014-08-21 21:23:48');
INSERT INTO `bc_touches` VALUES(181, 4, 7, '2014-08-21 21:26:13');
INSERT INTO `bc_touches` VALUES(182, 3, 7, '2014-08-21 21:29:18');
INSERT INTO `bc_touches` VALUES(183, 3, 7, '2014-08-21 21:33:06');
INSERT INTO `bc_touches` VALUES(184, 3, 8, '2014-08-21 21:38:51');
INSERT INTO `bc_touches` VALUES(185, 3, 8, '2014-08-21 21:39:45');
INSERT INTO `bc_touches` VALUES(186, 13, 8, '2014-08-21 21:42:39');
INSERT INTO `bc_touches` VALUES(187, 3, 6, '2014-08-22 00:23:31');
INSERT INTO `bc_touches` VALUES(188, 3, 6, '2014-08-22 00:36:11');
INSERT INTO `bc_touches` VALUES(189, 3, 8, '2014-08-22 02:05:11');
INSERT INTO `bc_touches` VALUES(190, 13, 8, '2014-08-22 02:05:30');
INSERT INTO `bc_touches` VALUES(191, 5, 8, '2014-08-22 02:05:42');
INSERT INTO `bc_touches` VALUES(192, 15, 8, '2014-08-22 02:05:49');
INSERT INTO `bc_touches` VALUES(193, 15, 8, '2014-08-22 02:06:05');
INSERT INTO `bc_touches` VALUES(194, 14, 8, '2014-08-22 02:06:12');
INSERT INTO `bc_touches` VALUES(195, 13, 8, '2014-08-22 02:06:19');
INSERT INTO `bc_touches` VALUES(196, 5, 8, '2014-08-22 02:06:30');
INSERT INTO `bc_touches` VALUES(197, 4, 8, '2014-08-22 02:06:36');
INSERT INTO `bc_touches` VALUES(198, 3, 8, '2014-08-22 02:06:46');
INSERT INTO `bc_touches` VALUES(199, 14, 8, '2014-08-22 02:50:33');
INSERT INTO `bc_touches` VALUES(200, 13, 8, '2014-08-22 02:50:39');
INSERT INTO `bc_touches` VALUES(201, 3, 8, '2014-08-22 02:50:47');
INSERT INTO `bc_touches` VALUES(202, 14, 8, '2014-08-22 02:51:34');
INSERT INTO `bc_touches` VALUES(203, 13, 8, '2014-08-22 02:52:03');
INSERT INTO `bc_touches` VALUES(204, 13, 8, '2014-08-22 02:52:11');
INSERT INTO `bc_touches` VALUES(205, 14, 8, '2014-08-22 02:52:20');
INSERT INTO `bc_touches` VALUES(206, 14, 8, '2014-08-22 02:52:21');
INSERT INTO `bc_touches` VALUES(207, 14, 8, '2014-08-22 02:52:49');
INSERT INTO `bc_touches` VALUES(208, 14, 8, '2014-08-22 02:52:54');
INSERT INTO `bc_touches` VALUES(209, 13, 8, '2014-08-22 02:54:56');
INSERT INTO `bc_touches` VALUES(210, 14, 8, '2014-08-22 02:55:21');
INSERT INTO `bc_touches` VALUES(211, 14, 8, '2014-08-22 02:55:26');
INSERT INTO `bc_touches` VALUES(212, 13, 8, '2014-08-22 15:28:02');
INSERT INTO `bc_touches` VALUES(213, 4, 8, '2014-08-22 15:28:17');
INSERT INTO `bc_touches` VALUES(214, 14, 8, '2014-08-22 15:28:28');
INSERT INTO `bc_touches` VALUES(215, 15, 8, '2014-08-22 15:28:46');
INSERT INTO `bc_touches` VALUES(216, 13, 8, '2014-08-22 15:29:02');
INSERT INTO `bc_touches` VALUES(217, 13, 8, '2014-08-22 15:32:49');
INSERT INTO `bc_touches` VALUES(218, 14, 8, '2014-08-22 15:33:06');
INSERT INTO `bc_touches` VALUES(219, 5, 6, '2014-08-23 18:37:50');
INSERT INTO `bc_touches` VALUES(220, 17, 6, '2014-08-23 18:37:56');
INSERT INTO `bc_touches` VALUES(221, 3, 6, '2014-08-26 22:25:20');
INSERT INTO `bc_touches` VALUES(222, 3, 6, '2014-08-27 00:05:10');
INSERT INTO `bc_touches` VALUES(223, 3, 6, '2014-08-27 00:27:48');
INSERT INTO `bc_touches` VALUES(224, 3, 6, '2014-08-27 00:28:00');
INSERT INTO `bc_touches` VALUES(225, 3, 6, '2014-08-27 00:28:52');
INSERT INTO `bc_touches` VALUES(226, 14, 0, '2014-09-08 23:40:30');
INSERT INTO `bc_touches` VALUES(227, 3, 0, '2014-09-09 01:12:52');
INSERT INTO `bc_touches` VALUES(228, 3, 0, '2014-09-09 01:27:31');
INSERT INTO `bc_touches` VALUES(229, 3, 0, '2014-09-09 01:35:45');
INSERT INTO `bc_touches` VALUES(230, 3, 1, '2014-09-10 20:14:15');
INSERT INTO `bc_touches` VALUES(231, 3, 1, '2014-09-10 20:16:35');
INSERT INTO `bc_touches` VALUES(232, 16, 1, '2014-09-10 20:22:07');
INSERT INTO `bc_touches` VALUES(233, 3, 1, '2014-09-10 20:26:40');
INSERT INTO `bc_touches` VALUES(234, 3, 1, '2014-09-10 20:27:00');
INSERT INTO `bc_touches` VALUES(235, 3, 0, '2014-09-10 23:43:10');
INSERT INTO `bc_touches` VALUES(236, 3, 0, '2014-09-11 00:03:40');
INSERT INTO `bc_touches` VALUES(237, 4, 0, '2014-09-11 00:19:37');
INSERT INTO `bc_touches` VALUES(238, 18, 0, '2014-09-11 00:20:22');
INSERT INTO `bc_touches` VALUES(239, 3, 0, '2014-09-11 00:24:59');
INSERT INTO `bc_touches` VALUES(240, 14, 0, '2014-09-11 00:30:10');
INSERT INTO `bc_touches` VALUES(241, 15, 0, '2014-09-11 00:30:22');

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `module_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `module_desc` text CHARACTER SET utf8 NOT NULL,
  `module_icon` varchar(100) CHARACTER SET utf8 NOT NULL,
  `ordering` int(3) NOT NULL,
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` VALUES(1, 'categories', 'Categories', 'glyphicon\r\nglyphicon-th-list', 4);
INSERT INTO `modules` VALUES(2, 'items', 'Items', 'glyphicon\r\nglyphicon-th-list', 4);
INSERT INTO `modules` VALUES(3, 'users', 'System Users', 'glyphicon glyphicon-cog', 9);
INSERT INTO `modules` VALUES(4, 'appusers', 'Registered Users', 'glyphicon glyphicon-th-list', 8);
INSERT INTO `modules` VALUES(5, 'likes', 'Item Likes', 'glyphicon\r\nglyphicon-th-list', 5);
INSERT INTO `modules` VALUES(6, 'reviews', 'Item Reviews', 'glyphicon\r\nglyphicon-th-list', 7);
INSERT INTO `modules` VALUES(7, 'inquiries', 'Item Inquiry', 'glyphicon\r\nglyphicon-th-list', 6);
INSERT INTO `modules` VALUES(9, 'reports', 'Analytic', 'glyphicon\r\nglyphicon-stats', 10);
INSERT INTO `modules` VALUES(10, 'feeds', 'News', 'glyphicon\r\nglyphicon-th-list', 1);
INSERT INTO `modules` VALUES(11, 'shop_info', 'Shop Information', 'glyphicon glyphicon-th-list', 2);
INSERT INTO `modules` VALUES(12, 'favourites', 'Item Favourite ', 'glyphicon glyphicon-th-list', 6);
INSERT INTO `modules` VALUES(13, 'contacts', 'Contact Messsages', 'glyphicon glyphicon-th-list', 3);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `user_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` VALUES(1, 1);
INSERT INTO `permissions` VALUES(1, 2);
INSERT INTO `permissions` VALUES(1, 3);
INSERT INTO `permissions` VALUES(1, 4);
INSERT INTO `permissions` VALUES(1, 5);
INSERT INTO `permissions` VALUES(1, 6);
INSERT INTO `permissions` VALUES(1, 7);
INSERT INTO `permissions` VALUES(1, 9);
INSERT INTO `permissions` VALUES(1, 10);
INSERT INTO `permissions` VALUES(1, 11);
INSERT INTO `permissions` VALUES(1, 12);
INSERT INTO `permissions` VALUES(1, 13);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `role_desc` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` VALUES(1, 'admin', 'Administrator');
INSERT INTO `roles` VALUES(2, 'manager', 'Manager');
INSERT INTO `roles` VALUES(3, 'user', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `role_access`
--

CREATE TABLE `role_access` (
  `role_id` int(11) NOT NULL,
  `action_id` varchar(50) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role_access`
--

INSERT INTO `role_access` VALUES(1, 'add');
INSERT INTO `role_access` VALUES(1, 'edit');
INSERT INTO `role_access` VALUES(1, 'delete');
INSERT INTO `role_access` VALUES(1, 'publish');
INSERT INTO `role_access` VALUES(2, 'add');
INSERT INTO `role_access` VALUES(2, 'edit');
INSERT INTO `role_access` VALUES(2, 'publish');
INSERT INTO `role_access` VALUES(3, 'add');
INSERT INTO `role_access` VALUES(1, 'module');
INSERT INTO `role_access` VALUES(1, 'ban');
INSERT INTO `role_access` VALUES(2, 'delete');
INSERT INTO `role_access` VALUES(3, 'edit');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `user_email` text CHARACTER SET utf8 NOT NULL,
  `user_pass` text CHARACTER SET utf8 NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_owner` tinyint(1) NOT NULL DEFAULT '0',
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES(1, 'admin', 'admin@beautician.com', '21232f297a57a5a743894a0e4a801fc3', 1, 1, '2014-07-28 14:05:36', 1);
